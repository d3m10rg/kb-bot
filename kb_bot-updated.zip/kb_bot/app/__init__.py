"""Telegram group moderation bot."""

